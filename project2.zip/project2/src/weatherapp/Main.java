package weatherapp;

public class Main{
    public static void main(String[] args) throws InterruptedException {
        App a = new App();
        a.run();
    }
}
